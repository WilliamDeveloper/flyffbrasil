Coming Soon: 

Skill Macros

You can build your own macros with this feature. They are bounded on keys or key combinations.
There will be functions like breaks, loops and so on. Usually it should detach the Buffer function
and give some enhanced features for leveling.


Feeder / Spammer Step by Step:

- Select the Skillbar where your Shortcut locates.
- Select the F-Key for your Shortcut
- You may change the Interval which indicates the repeat time period
- Click on Select Window, and select the desired window 
  hint: if you have multiple clients open, use Jump To
- Now start the Function


Buffer Step by Step:

- Under the rider Buffer is a field called Options, select the desired function and set the interval
- If you selected �Use Buffs�, you have to check them on the left side
- Now go to the rider Buff Options and place your skills
  hint: �FIRST Buff Window� define the buffs for �FIRST Buffer�
- Jump back to the rider Buffer, and select your desired window
- Finally start the Function

Collector Step by Step:

- drag the collector window in the upper left corner (look at the image in your FTool Extended folder)
- Select the F-Key for the Battery shortcut
- Click on Select Window, and select the desired window 
  hint: if you have multiple clients open, use Jump To
- Now press the Start button


